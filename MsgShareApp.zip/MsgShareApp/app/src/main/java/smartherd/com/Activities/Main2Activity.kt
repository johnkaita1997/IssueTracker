package smartherd.com.Activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main2.*
import smartherd.com.AppConstants.Constants
import smartherd.com.R

class Main2Activity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        initall()
    }

    fun initall() {

        loadIntentBundles()
    }

    private fun loadIntentBundles() {
        val bundle: Bundle? = intent.extras

        //First check if bundle is not null first
        //The below will be done only if bundle is not null
        bundle?.let {
            val message = bundle.getString(Constants.USER_MESG_KEY)
            //Set the value to the textview
            textView.text = message
        }


    }
}
